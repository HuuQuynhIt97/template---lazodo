<html>
<meta http-equiv='Content-type' content='text/html; charset=UTF-8'>
<head>
<title>Access denied</title>
</head>
Access denied!If you have any questions, please contact using the IT department 拒絕存取!如有任何使用上問題請洽電腦室 <bR>
</html>